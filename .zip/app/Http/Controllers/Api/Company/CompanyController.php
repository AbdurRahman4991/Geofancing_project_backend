<?php

namespace App\Http\Controllers\Api\Company;
use App\Services\Company\CompanyService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
      protected $companyService;

    public function __construct(CompanyService $companyService)
    {
        $this->companyService = $companyService;
    }

    public function index()
    {
        return response()->json($this->companyService->all());
    }

    public function store(Request $request)
    {
        $request->validate([
            'company_name' => 'required|string|max:255',
            'email' => 'nullable|email',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:255',
        ]);

        $company = $this->companyService->store($request);
        return response()->json($company, 201);
    }

    public function show($id)
    {
        return response()->json($this->companyService->show($id));
    }

    public function update(Request $request, $id)
    {
        $company = $this->companyService->update($request, $id);
        return response()->json($company);
    }

    public function destroy($id)
    {
        $this->companyService->destroy($id);
        return response()->json(['message' => 'Company deleted successfully']);
    }
}
