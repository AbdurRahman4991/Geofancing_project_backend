<?php

namespace App\Services\Company;

use App\Models\Company;
use Illuminate\Http\Request;

class CompanyService
{
    public function all()
    {
        return Company::all();
    }

    public function store(Request $request)
    {
        return Company::create($request->only(['company_name', 'email', 'phone', 'address']));
    }

    public function show($id)
    {
        return Company::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $company = Company::findOrFail($id);
        $company->update($request->only(['company_name', 'email', 'phone', 'address']));
        return $company;
    }

    public function destroy($id)
    {
        $company = Company::findOrFail($id);
        $company->delete();
        return true;
    }
}
