<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Helal Uddin\Desktop\flutter\backend\example-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>