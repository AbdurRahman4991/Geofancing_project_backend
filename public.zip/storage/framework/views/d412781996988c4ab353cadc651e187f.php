<?php echo e($slot); ?>

<?php /**PATH C:\Users\Helal Uddin\Desktop\flutter\backend\example-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>